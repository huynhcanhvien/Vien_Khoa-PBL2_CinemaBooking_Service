package com.example.cinemabooking_service.repository;

import com.example.cinemabooking_service.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUserId(String user_id);

    @Query("SELECT SUM(b.bookingPrice) FROM Booking b WHERE b.bookingDate = :bookingDate")
    BigDecimal calculateRevenueByDate(@Param("bookingDate") LocalDate bookingDate);
}
