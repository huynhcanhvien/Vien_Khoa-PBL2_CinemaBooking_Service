package com.example.cinemabooking_service.controller;

import com.example.cinemabooking_service.dto.request.MovieRequest.MovieCreationRequest;
import com.example.cinemabooking_service.dto.response.ApiResponse;
import com.example.cinemabooking_service.dto.response.MovieResponse;
import com.example.cinemabooking_service.service.MovieService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/movie")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MovieController {
    MovieService movieService;

    @GetMapping
    public List<MovieResponse> getAllMovies() {
        return movieService.getAllMovies();
    }
    @GetMapping("/{movieId}")
    public ApiResponse<MovieResponse> getMovieById(@PathVariable("movieId") String movieId) {
        return ApiResponse.<MovieResponse>builder()
                .result(movieService.getMovieById(movieId))
                .build();
    }

    @PostMapping("/create")
    public ApiResponse<MovieResponse> createMovie(@RequestBody MovieCreationRequest movieCreationRequest) {
        return ApiResponse.<MovieResponse>builder()
                .result(movieService.createMovie(movieCreationRequest))
                .build();
    }
    @GetMapping("/search/{title}")
    public ApiResponse<List<MovieResponse>> getMovieByTitle(@PathVariable("title") String title) {
        return ApiResponse.<List<MovieResponse>>builder()
                .result(movieService.searchMovies(title))
                .build();
    }
    @PatchMapping("/update/{movieId}")
    public ApiResponse<MovieResponse> updateMovie(@PathVariable("movieId") String movieId, @RequestBody Map<String, Object> movieUpdateRequest){
        return ApiResponse.<MovieResponse>builder()
                .result(movieService.updateMovie(movieId, movieUpdateRequest))
                .build();
    }

    @DeleteMapping("/{movieId}")
    public ApiResponse<Void> deleteMovie(@PathVariable("movieId") String movieId) {
        movieService.deleteMovie(movieId);
        return ApiResponse.<Void>builder()
                .code(1000)
                .message("Movie deleted")
                .build();
    }
}
