package com.example.cinemabooking_service.mapper;

import com.example.cinemabooking_service.dto.request.UserRequest.UserCreationRequest;
import com.example.cinemabooking_service.dto.request.UserRequest.UserUpdateRequest;
import com.example.cinemabooking_service.dto.response.UserResponse;
import com.example.cinemabooking_service.entity.User;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface UserMapper {
    User toUser(UserCreationRequest request);
    void updateUser(@MappingTarget User user, UserUpdateRequest request);
    UserResponse toUserResponse(User user);
}
