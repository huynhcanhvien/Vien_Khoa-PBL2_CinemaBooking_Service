package com.example.cinemabooking_service.controller;

import com.example.cinemabooking_service.dto.request.UserRequest.UserCreationRequest;
import com.example.cinemabooking_service.dto.request.UserRequest.UserUpdateRequest;
import com.example.cinemabooking_service.dto.response.UserResponse;
import com.example.cinemabooking_service.entity.User;
import com.example.cinemabooking_service.dto.response.ApiResponse;
import com.example.cinemabooking_service.mapper.UserMapper;
import com.example.cinemabooking_service.service.UserService;
import jakarta.validation.Valid;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class UserController {
    UserService userService;
    UserMapper userMapper;
    //Post
    @PostMapping
    public ApiResponse<UserResponse> createUser(@RequestBody @Valid UserCreationRequest request) {
        UserResponse userResponse = userService.createUser(request);
        return ApiResponse.<UserResponse>builder()
                .result(userResponse)
                .build();
    }
    @GetMapping("/myBookings")
    public ApiResponse<Object> getAllBookings() {
        return ApiResponse.builder()
                .result(userService.getListBooked())
                .build();
    }
    //Get
    @GetMapping("/getById/{userId}")
    public UserResponse getUserById(@PathVariable("userId") String userId) {
        return userMapper.toUserResponse(userService.getUserById(userId));
    }

    @GetMapping("/username/{username}")
    public User getUserByUsername(@PathVariable("username") String username) {
        return userService.getUserByUsername(username);
    }

    @GetMapping("/all")
    public List<UserResponse> getAllUsers() {
        List<UserResponse> userResponses = new ArrayList<>();
        userService.getAllUsers().forEach(user -> userResponses.add(userMapper.toUserResponse(user)));
        return userResponses;
    }

    @GetMapping("/selfInfo")
    public ApiResponse<UserResponse> getMyInfo(){
        return ApiResponse.<UserResponse>builder()
                .result(userService.getMyInfo())
                .build();
    }
    //Update
    @PatchMapping("/{userId}")
    public User updateUser(@PathVariable("userId") String userId, @RequestBody UserUpdateRequest request) {
        return  userService.updateUser(request,userId);
    }
}
