package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Seat {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(nullable = false)
    char charRow;
    @Column(nullable = false)
    int numCol;
    @ManyToOne
    @JoinColumn(name = "theater_id")
    Theater theater;

    @ManyToMany(mappedBy = "seats")
    List<Booking> bookings;

    public Seat(char charRow, int numCol, Theater theater) {
        this.charRow = charRow;
        this.numCol = numCol;
        this.theater = theater;
    }

    public boolean isBookedForScreening(Screening screening) {
        return bookings.stream().anyMatch(booking -> booking.getScreening().equals(screening));
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
        if(theater != null && !theater.getSeats().contains(this)) {
            theater.getSeats().add(this);
        }
    }
    public void removeTheater() {
        theater.getSeats().remove(this);
        this.theater = null;
    }
    public void addBooking(Booking booking) {
        if (!bookings.contains(booking)) {
            bookings.add(booking);
            booking.addSeat(this);
        }
    }

    public void removeBooking(Booking booking) {
        if (bookings.contains(booking)) {
            bookings.remove(booking);
            booking.removeSeat(this); 
        }
    }
    public String toCode(){
        return this.charRow + "" + this.numCol;
    }
}
