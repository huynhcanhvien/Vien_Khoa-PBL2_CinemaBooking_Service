package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.response.TheaterResponse;
import com.example.cinemabooking_service.entity.Seat;
import com.example.cinemabooking_service.entity.Theater;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.repository.TheaterRepository;
import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class TheaterService {
    TheaterRepository theaterRepository;

    public TheaterResponse addTheater( String theaterName, int totalSeats, int seatPerRows) throws AppException {
        Theater theater = new Theater();
        theater.setName(theaterName);
        theater.setTotalSeats(totalSeats);
        theater.setSeatsAvailable(totalSeats);
        theater.setSeatsPerRow(seatPerRows);
        theater.generateSeats();
        theaterRepository.save(theater);
        return TheaterResponse.builder()
                .name(theaterName)
                .totalSeats(totalSeats)
                .seatsAvailable(totalSeats)
                .build();
    }

    public TheaterResponse update(Long theaterId, int totalSeats) {
        Theater theater = theaterRepository.findById(theaterId).orElseThrow(() -> new AppException(ErrorCode.THEATER_NOT_FOUND));
        theater.setTotalSeats(totalSeats);
        theaterRepository.save(theater);
        return TheaterResponse.builder()
                .name(theater.getName())
                .totalSeats(totalSeats)
                .build();
    }

    @Transactional
    public boolean delete(Long theaterId) {
        if(theaterRepository.existsById(theaterId)) {
            theaterRepository.deleteById(theaterId);
            return true;
        }
        return false;
    }

    public TheaterResponse findById(Long theaterId) {
        Theater theater = theaterRepository.findById(theaterId).orElseThrow(() -> new AppException(ErrorCode.THEATER_NOT_FOUND));
        List<String> seatCode = new ArrayList<>();
        for(Seat seat : theater.getSeats()) {
            seatCode.add(seat.toCode());
        }
        return TheaterResponse.builder()
                .name(theater.getName())
                .totalSeats(theater.getTotalSeats())
                .seatsAvailable(theater.getSeatsAvailable())
                .seats(seatCode)
                .build();
    }

    public TheaterResponse findByName(String name) {
        Theater theater = theaterRepository.findByName(name).orElseThrow(() -> new AppException(ErrorCode.THEATER_NOT_FOUND));
        List<String> seatCode = new ArrayList<>();
        for(Seat seat : theater.getSeats()) {
            seatCode.add(seat.toCode());
        }
        return TheaterResponse.builder()
                .name(theater.getName())
                .seatsAvailable(theater.getSeatsAvailable())
                .totalSeats(theater.getTotalSeats())
                .seats(seatCode)
                .build();
    }

    public List<Long> getAllTheater(){
        List<Theater> theaters = theaterRepository.findAll();
        List<Long> theaterIds = new ArrayList<>();
        for(Theater theater : theaters) {
            theaterIds.add(theater.getId());
        }
        return theaterIds;

    }
}
