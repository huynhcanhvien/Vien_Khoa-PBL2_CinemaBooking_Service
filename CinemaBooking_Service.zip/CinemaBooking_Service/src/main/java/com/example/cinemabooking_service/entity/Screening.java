package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Slf4j
public class Screening {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    String id;

    LocalDate dateShow;
    LocalTime startTime;
    LocalTime endTime;

    @ManyToOne
    @JoinColumn(name = "movie_id")
    Movie movie;

    @ManyToOne
    @JoinColumn(name = "theater_id")
    Theater theater;

    @OneToMany(mappedBy = "screening", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Booking> bookings = new ArrayList<>();

    public void setMovie(Movie movie) {
        this.movie = movie;
        if (movie != null && !movie.getScreenings().contains(this)) {
            movie.addScreening(this);
        }
    }

    public void setTheater(Theater theater) {
        this.theater = theater;
        if(theater != null && !theater.getScreenings().contains(this)) {
            theater.addScreening(this);
        }
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
        if(!booking.getScreening().equals(this)){
            booking.setScreening(this);
        }
    }

}
