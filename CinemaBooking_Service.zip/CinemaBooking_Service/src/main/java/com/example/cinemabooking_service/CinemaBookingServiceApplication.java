package com.example.cinemabooking_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@SpringBootApplication
public class CinemaBookingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CinemaBookingServiceApplication.class, args);
        System.out.println(LocalDate.now());
    }

}
