package com.example.cinemabooking_service.dto.request;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ScreeningRequest {
    LocalDate dateShow;
    LocalTime startTime;
    String movieId;
    Long theaterId;
}
