package com.example.cinemabooking_service.dto.request.MovieRequest;

import lombok.*;
import lombok.experimental.FieldDefaults;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MovieCreationRequest {
    String title;
    int duration; //in minutes
    String directorName;
    String genre;
    int forAge;
    BigDecimal price;
    LocalDate releaseDate;
    String country;
    String language;
    String description;
    String posterURL;
}
