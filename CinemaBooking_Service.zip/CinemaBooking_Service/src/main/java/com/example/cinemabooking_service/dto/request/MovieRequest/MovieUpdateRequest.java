package com.example.cinemabooking_service.dto.request.MovieRequest;

import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MovieUpdateRequest {
    String title;
    int duration; //in minutes
    String directorName;
    String genre;
    int forAge;
    BigDecimal price;
    LocalDate releaseDate;
    String description;
    String posterURL;
    String country;
    String language;
}
