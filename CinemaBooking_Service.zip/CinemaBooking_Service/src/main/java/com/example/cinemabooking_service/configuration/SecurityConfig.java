package com.example.cinemabooking_service.configuration;

import com.example.cinemabooking_service.controller.CustomJwtDecoder;
import com.example.cinemabooking_service.enums.ROLES;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;


@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    private final String[] PUBLIC_ENDPOINTS = {"/user",
                                        "/auth/login", "/auth/introspect"
                                        ,"/auth/logout", "/auth/refresh"
    };
    private final String[] PUBLIC_GET_ENDPOINTS = {
            "/movie","/movie/{movieId}",
            "/screening/movie/{movieId}",
            "/screening/seats/{screeningId}"
            ,"/screening/{screeningId}"
            ,"/theater/{theaterId}", "/theater/theaterName/{theaterName}"
    };

    @Autowired
    private CustomJwtDecoder customJwtDecoder;

    private final String[] ADMIN_ENDPOINTS_POST = {"/movie/create", "/theater/add", "/screening/create"};
    private final String[] ADMIN_ENDPOINTS_GET = {"/user/getById/{userId}", "/user/username/{username}", "/user/all"};
    private final String[] ADMIN_ENDPOINTS_PATCH = {"/user/{userId}","/movie/update/{movieId}", "/theater/update/{theaterId}"
            , "/screening/update/{screeningId}"};
    private final String[] ADMIN_ENDPOINTS_DELETE = {"/movie/{movieId}", "/theater/{theaterId}", "/screening/{screeningId}"};
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        httpSecurity.cors(cors -> cors.configurationSource(corsConfigurationSource()));
        httpSecurity.oauth2ResourceServer(oauth2 ->
                oauth2.jwt(jwtConfigurer -> jwtConfigurer.decoder(customJwtDecoder)
                        .jwtAuthenticationConverter(jwtAuthenticationConverter()))
        );

        httpSecurity
                .authorizeHttpRequests(request -> request
                        .requestMatchers(HttpMethod.POST, PUBLIC_ENDPOINTS).permitAll()
                        .requestMatchers(HttpMethod.GET, PUBLIC_GET_ENDPOINTS).permitAll()
                        .requestMatchers(HttpMethod.POST, ADMIN_ENDPOINTS_POST).hasRole(ROLES.ADMIN.name())
                        .requestMatchers(HttpMethod.GET, ADMIN_ENDPOINTS_GET).hasRole(ROLES.ADMIN.name())
                        .requestMatchers(HttpMethod.PATCH, ADMIN_ENDPOINTS_PATCH).hasRole(ROLES.ADMIN.name())
                        .requestMatchers(HttpMethod.DELETE, ADMIN_ENDPOINTS_DELETE).hasRole(ROLES.ADMIN.name())
                        .anyRequest().authenticated()
                );

        httpSecurity.csrf(AbstractHttpConfigurer::disable);
        return httpSecurity.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10);
    }
    @Bean
    JwtAuthenticationConverter jwtAuthenticationConverter() {

        JwtGrantedAuthoritiesConverter jwtGrantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        jwtGrantedAuthoritiesConverter.setAuthorityPrefix("ROLE_");
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(jwtGrantedAuthoritiesConverter);

        return jwtAuthenticationConverter;
    }
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.addAllowedOrigin("*");
        corsConfiguration.addAllowedHeader("*");
        corsConfiguration.addAllowedMethod("*");
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfiguration);
        return source;
    }
}
