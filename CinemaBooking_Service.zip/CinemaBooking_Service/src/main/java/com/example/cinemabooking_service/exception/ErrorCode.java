package com.example.cinemabooking_service.exception;

public enum ErrorCode {
    UNCATEGORIZED_EXCEPTION(9999, "Uncategorized Exception"),
    USER_EXISTED(1001, "User already existed"),
    USERNAME_EXISTED(1002, "Username already existed"),
    USERNAME_INVALID(1003, "Username must be at least 3 characters"),
    PASSWORD_INVALID(1004, "Password must be at least 6 characters"),
    USERNAME_NOT_FOUND(1005, "Username not found"),
    UNAUTHENTICATED(1006, "Unauthenticated"),
    UNINTROSPECTIVE(1007, "Unintrospective"),
    UNVALIDATED(1008, "Unvalidated"),
    MOVIE_NOT_FOUND(1009, "Movie not found"),
    SCREENING_IS_OVERLAPPED(10010, "Screening is overlapped"),
    SCREENING_NOT_FOUND(10011, "Screening not found"),
    SEAT_NOT_FOUND(10012, "Seat not found"),
    SEAT_IS_BOOKED(10013, "Seat is booked"),
    TOKEN_EXPIRED(10014, "Token expired"),
    THEATER_NOT_FOUND(10015, "Theater not found"),
    ;
    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }
    private int code;
    private String message;

    public int getCode() {
        return code;
    }
    public String getMessage() {
        return message;
    }
}
