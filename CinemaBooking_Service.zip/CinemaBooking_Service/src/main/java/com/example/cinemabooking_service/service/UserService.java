package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.request.UserRequest.UserCreationRequest;
import com.example.cinemabooking_service.dto.request.UserRequest.UserUpdateRequest;
import com.example.cinemabooking_service.dto.response.BookingResponse;
import com.example.cinemabooking_service.dto.response.ScreeningResponse;
import com.example.cinemabooking_service.dto.response.UserResponse;
import com.example.cinemabooking_service.entity.Booking;
import com.example.cinemabooking_service.entity.User;
import com.example.cinemabooking_service.enums.ROLES;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.mapper.UserMapper;
import com.example.cinemabooking_service.repository.BookingRepository;
import com.example.cinemabooking_service.repository.UserRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class UserService {
    UserRepository userRepository;
    UserMapper userMapper;
    BookingRepository bookingRepository;

    public UserResponse createUser(UserCreationRequest userCreationRequest){
        User user = new User();
        if(userRepository.existsByUsername(userCreationRequest.getUsername())){
            throw new AppException(ErrorCode.USERNAME_EXISTED);
        }

        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);

        user = userMapper.toUser(userCreationRequest);
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        HashSet<String> roles = new HashSet<>();
        roles.add(ROLES.USER.name());

        user.setRoles(roles);

        return userMapper.toUserResponse(userRepository.save(user));
    }
    @PostAuthorize("returnObject.username == authentication.name")
    public User getUserById(String userId){
        return userRepository.findById(userId).orElseThrow(() -> new RuntimeException("Id Not Found"));
    }

    public User getUserByUsername(String username){
        return  userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("Username not found"));
    }

    public User updateUser(UserUpdateRequest request, String userId){
        User user = userRepository.findById(userId).orElseThrow(() -> new AppException(ErrorCode.USERNAME_INVALID));
        userMapper.updateUser(user, request);
        return userRepository.save(user);
    }
    public List<BookingResponse> getListBooked(){
        var context = SecurityContextHolder.getContext();
        String userName = context.getAuthentication().getName();
        User user = userRepository.findByUsername(userName).orElseThrow(() -> new AppException(ErrorCode.USERNAME_INVALID));
        String userId = user.getId();

        List<Booking> bookings = bookingRepository.findByUserId(userId);
        List<BookingResponse> bookingResponses = new ArrayList<>();
        for(Booking booking : bookings){
            ScreeningResponse screeningResponse = ScreeningResponse.builder()
                    .dateShow(booking.getScreening().getDateShow())
                    .theaterName(booking.getScreening().getTheater().getName())
                    .startTime(booking.getScreening().getStartTime())
                    .endTime(booking.getScreening().getEndTime())
                    .movieName(booking.getScreening().getMovie().getTitle())
                    .build();
            BookingResponse bookingResponse = BookingResponse.builder()
                    .BookedDate(booking.getBookingDate())
                    .price(booking.getBookingPrice())
                    .BookedTime(booking.getBookingTime())
                    .seatCodes(booking.getBookedSeatCodes())
                    .screeningResponse(screeningResponse)
                    .build();
            bookingResponses.add(bookingResponse);
        }
        bookingResponses.sort((x, y) -> LocalDateTime.of(y.getBookedDate(), y.getBookedTime()).compareTo(LocalDateTime.of(x.getBookedDate(), x.getBookedTime())));
        return bookingResponses;
    }

    @PreAuthorize("hasRole('ADMIN')")
    public List<User> getAllUsers(){
        return userRepository.findAll();
    }

    public UserResponse getMyInfo(){
        var context = SecurityContextHolder.getContext();
        String username = context.getAuthentication().getName();
        return userMapper.toUserResponse(userRepository
                .findByUsername(username)
                .orElseThrow(() -> new AppException(ErrorCode.USERNAME_INVALID))
        );
    }
}
