package com.example.cinemabooking_service.mapper;

import com.example.cinemabooking_service.dto.request.MovieRequest.MovieCreationRequest;
import com.example.cinemabooking_service.dto.request.MovieRequest.MovieUpdateRequest;
import com.example.cinemabooking_service.dto.response.MovieResponse;
import com.example.cinemabooking_service.entity.Movie;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper(componentModel = "spring")
public interface MovieMapper {
    Movie toMovie(MovieCreationRequest request);
    void updateMovie(@MappingTarget Movie movie, MovieUpdateRequest request);
    MovieResponse toMovieResponse(Movie movie);
}
