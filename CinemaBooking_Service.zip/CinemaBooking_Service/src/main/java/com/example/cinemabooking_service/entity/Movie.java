package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    String id;
    String country;
    String language;
    String title;
    int duration; //in minutes
    String directorName;
    String genre;
    int forAge;
    BigDecimal price;
    LocalDate releaseDate;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String description;

    String posterURL;

    @OneToMany(mappedBy =  "movie", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Screening> screenings = new ArrayList<>();

    public void addScreening(Screening screening){
        if(this.screenings==null){
            this.screenings = new ArrayList<>();
        }
        this.screenings.add(screening);
        screening.setMovie(this);
    }
}
