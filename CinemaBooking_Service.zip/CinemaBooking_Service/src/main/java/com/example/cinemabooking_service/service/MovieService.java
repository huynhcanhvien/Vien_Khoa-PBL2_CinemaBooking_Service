package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.request.MovieRequest.MovieCreationRequest;
import com.example.cinemabooking_service.dto.response.MovieResponse;
import com.example.cinemabooking_service.entity.Movie;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.mapper.MovieMapper;
import com.example.cinemabooking_service.repository.MovieRepository;
import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MovieService {

    MovieRepository movieRepository;

    MovieMapper movieMapper;

    public List<MovieResponse> getAllMovies() {
        List<MovieResponse> movieResponseList = new ArrayList<>();
        movieRepository.findAll().forEach(movie -> movieResponseList.add(movieMapper.toMovieResponse(movie)));
        return movieResponseList;
    }
    public MovieResponse getMovieById(String movieId) {
        Movie movie = movieRepository.findById(movieId).orElseThrow(() -> new AppException(ErrorCode.MOVIE_NOT_FOUND));
        return movieMapper.toMovieResponse(movie);
    }
    public MovieResponse createMovie(MovieCreationRequest movieCreationRequest) {
        Movie movie = movieMapper.toMovie(movieCreationRequest);
        return movieMapper.toMovieResponse(movieRepository.save(movie));
    }
    public MovieResponse updateMovie(String movieId, Map<String, Object> movieUpdateRequest) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new AppException(ErrorCode.MOVIE_NOT_FOUND));

        if (movieUpdateRequest.containsKey("title")) {
            movie.setTitle(movieUpdateRequest.get("title").toString());
        }

        if (movieUpdateRequest.containsKey("duration")) {
            Object durationObj = movieUpdateRequest.get("duration");
            if (durationObj instanceof Integer) {
                movie.setDuration((Integer) durationObj);
            } else {
                movie.setDuration(Integer.parseInt(durationObj.toString()));
            }
        }

        if (movieUpdateRequest.containsKey("directorName")) {
            movie.setDirectorName(movieUpdateRequest.get("directorName").toString());
        }

        if (movieUpdateRequest.containsKey("genre")) {
            movie.setGenre(movieUpdateRequest.get("genre").toString());
        }

        if (movieUpdateRequest.containsKey("forAge")) {
            Object forAgeObj = movieUpdateRequest.get("forAge");
            if (forAgeObj instanceof Integer) {
                movie.setForAge((Integer) forAgeObj);
            } else {
                movie.setForAge(Integer.parseInt(forAgeObj.toString()));
            }
        }

        if (movieUpdateRequest.containsKey("price")) {
            Object priceObj = movieUpdateRequest.get("price");
            if (priceObj instanceof BigDecimal) {
                movie.setPrice((BigDecimal) priceObj);
            } else {
                movie.setPrice(new BigDecimal(priceObj.toString()));
            }
        }

        if (movieUpdateRequest.containsKey("releaseDate")) {
            movie.setReleaseDate(LocalDate.parse(movieUpdateRequest.get("releaseDate").toString()));
        }

        if (movieUpdateRequest.containsKey("description")) {
            movie.setDescription(movieUpdateRequest.get("description").toString());
        }

        if (movieUpdateRequest.containsKey("posterURL")) {
            movie.setPosterURL(movieUpdateRequest.get("posterURL").toString());
        }

        return movieMapper.toMovieResponse(movieRepository.save(movie));
    }

    public List<MovieResponse> searchMovies(String title) {
        List<MovieResponse> movieResponseList = new ArrayList<>();
        movieRepository.findByTitleContainingIgnoreCase(title).forEach(
                movie -> movieResponseList.add(movieMapper.toMovieResponse(movie))
        );
        return movieResponseList;
    }
    @Transactional
    public void deleteMovie(String movieId) {
        boolean exists = movieRepository.existsById(movieId);
        if (exists) {
            movieRepository.deleteById(movieId);
        }
        else{
            throw new AppException(ErrorCode.MOVIE_NOT_FOUND);
        }
    }
}
