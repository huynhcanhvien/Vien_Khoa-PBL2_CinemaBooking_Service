package com.example.cinemabooking_service.dto.request;

import lombok.*;
import lombok.experimental.FieldDefaults;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TheaterRequest {
    String name;
    int totalSeat;
    int seatPerRow;
}
