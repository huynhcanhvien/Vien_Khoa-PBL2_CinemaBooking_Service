package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    String id;
    Set<String> roles;
    @Column(name = "username", unique = true, nullable = false)
    String username;
    String password;
    String email;
    String firstname;
    String lastname;
    LocalDate birthday;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Booking> bookings;


    public void addBooking(Booking booking) {
        bookings.add(booking);
        if(!booking.getUser().equals(this)) {
            booking.setUser(this);
        }
    }

    @Transactional
    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

}
