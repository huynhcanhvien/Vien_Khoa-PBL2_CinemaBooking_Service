package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.request.ScreeningRequest;
import com.example.cinemabooking_service.dto.response.BookedSeatResponse;
import com.example.cinemabooking_service.dto.response.ScreeningOfMovieResponse;
import com.example.cinemabooking_service.dto.response.ScreeningResponse;
import com.example.cinemabooking_service.entity.*;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.repository.MovieRepository;
import com.example.cinemabooking_service.repository.ScreeningRepository;
import com.example.cinemabooking_service.repository.TheaterRepository;
import jakarta.transaction.Transactional;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class ScreeningService {
    ScreeningRepository screeningRepository;
    MovieRepository movieRepository;
    TheaterRepository theaterRepository;

    private boolean checkScreeningIsOverlap(Screening screening, Long theaterId) {
        Theater theater = theaterRepository.findById(theaterId).orElseThrow(() -> new AppException(ErrorCode.THEATER_NOT_FOUND));

        List<Screening> screenings = theater.getScreenings();
        if (screenings == null || screenings.isEmpty()) {
            log.info("No screenings found for theater ID: {}", theaterId);
            return false;
        }

        for (Screening existedScreening : screenings) {
            if(existedScreening.getDateShow().equals(screening.getDateShow())) {
                LocalTime startTime = existedScreening.getStartTime();
                LocalTime endTime = existedScreening.getEndTime();

                log.info("Checking overlap: new screening start time = {}, end time = {}", screening.getStartTime(), screening.getEndTime());
                log.info("Existing screening start time = {}, end time = {}", startTime, endTime);

                if (screening.getStartTime().isBefore(endTime) && screening.getEndTime().isAfter(startTime) && endTime.isAfter(LocalTime.of(6,0,0))) {
                    log.info("Overlap detected!");
                    return true;
                }
            }
        }
        return false;
    }
    
    public ScreeningResponse createScreening(ScreeningRequest screeningRequest){
        Movie movie = movieRepository.findById(screeningRequest.getMovieId()).orElseThrow(() -> new AppException(ErrorCode.MOVIE_NOT_FOUND));
        Theater theater = theaterRepository.findById(screeningRequest.getTheaterId()).orElseThrow(() -> new AppException(ErrorCode.THEATER_NOT_FOUND));

        Screening screening = new Screening();
        screening.setDateShow(screeningRequest.getDateShow());
        screening.setStartTime(screeningRequest.getStartTime());
        screening.setEndTime(screeningRequest.getStartTime().plusMinutes(movie.getDuration()));

        screening.setMovie(movie);
        if(checkScreeningIsOverlap(screening, theater.getId())) throw new AppException(ErrorCode.SCREENING_IS_OVERLAPPED);
        screening.setTheater(theater);

        screeningRepository.save(screening);

       return ScreeningResponse.builder()
               .screeningId(screening.getId())
                .dateShow(screening.getDateShow())
                .startTime(screening.getStartTime())
                .endTime(screening.getEndTime())
                .theaterName(theater.getName())
                .movieName(movie.getTitle())
                .build();

    }

    public ScreeningResponse updateScreening(String screeningId, Map<String, Object> screeningRequest){
        Screening screeningUpdate = screeningRepository.findById(screeningId).orElseThrow(() -> new AppException(ErrorCode.SCREENING_NOT_FOUND));
        Theater theater = new Theater();
        Movie movie = new Movie();
        if(screeningRequest.containsKey("dateShow")){
            screeningUpdate.setDateShow(LocalDate.parse(screeningRequest.get("dateShow").toString()));
        }
        if(screeningRequest.containsKey("movieId")){
            movie = movieRepository.findById(screeningRequest.get("movieId").toString()).orElseThrow(() -> new AppException(ErrorCode.MOVIE_NOT_FOUND));
            screeningUpdate.setMovie(movie);
        }
        if(screeningRequest.containsKey("startTime")){
            screeningUpdate.setStartTime(LocalTime.parse(screeningRequest.get("startTime").toString()));
            screeningUpdate.setEndTime(screeningUpdate.getStartTime()
                    .plusMinutes(movie.getDuration()
                    )
            );
        }
        if(screeningRequest.containsKey("theaterId")){
            theater = theaterRepository
                    .findById((Long) screeningRequest.get("theaterId"))
                    .orElseThrow(() -> new AppException(ErrorCode.UNVALIDATED));
            screeningUpdate.setTheater(theater);
        }
        if(checkScreeningIsOverlap(screeningUpdate, screeningUpdate.getTheater().getId())) throw new AppException(ErrorCode.SCREENING_IS_OVERLAPPED);
        return ScreeningResponse.builder()
                .screeningId(screeningUpdate.getId())
                .dateShow(screeningUpdate.getDateShow())
                .startTime(screeningUpdate.getStartTime())
                .movieName(movie.getTitle())
                .theaterName(theater.getName())
                .build();
    }

    @Transactional
    public boolean deleteScreening(String screeningId){
        boolean existed = screeningRepository.existsById(screeningId);
        if(existed) {
            screeningRepository.deleteById(screeningId);
        }
        return existed;
    }

    public ScreeningResponse getScreening(String screeningId){
        Screening screening = screeningRepository.findById(screeningId).orElseThrow(() -> new AppException(ErrorCode.SCREENING_NOT_FOUND));
        Theater theater = screening.getTheater();
        Movie movie = screening.getMovie();
        return ScreeningResponse.builder()
                .screeningId(screening.getId())
                .dateShow(screening.getDateShow())
                .startTime(screening.getStartTime())
                .theaterName(theater.getName())
                .movieName(movie.getTitle())
                .build();
    }

    public ScreeningOfMovieResponse getAllScreenings(String movieId){
        ScreeningOfMovieResponse screeningOfMovieResponse = new ScreeningOfMovieResponse();
        List<Screening> screenings = movieRepository.findById(movieId).orElseThrow(() -> new AppException(ErrorCode.MOVIE_NOT_FOUND)).getScreenings();
        for(Screening screening : screenings){
            LocalDateTime timeShow = LocalDateTime.of(screening.getDateShow(), screening.getStartTime());
            if(timeShow.isAfter(LocalDateTime.now())){
                ScreeningResponse screeningResponse = ScreeningResponse.builder()
                        .screeningId(screening.getId())
                        .dateShow(screening.getDateShow())
                        .startTime(screening.getStartTime())
                        .theaterName(screening.getTheater().getName())
                        .movieName(screening.getMovie().getTitle())
                        .build();
                screeningOfMovieResponse.addScreening(screeningResponse);
            }

        }
        screeningOfMovieResponse.sort();
        return screeningOfMovieResponse;
    }
    private List<String> getAllBookedSeat(String screeningId){
        List<String> bookedSeats = new ArrayList<>();
        Screening screening = screeningRepository.findById(screeningId).orElseThrow(() -> new AppException(ErrorCode.SCREENING_NOT_FOUND));
        List<Booking> bookings = screening.getBookings();
        for(Booking booking : bookings){
            List<Seat> seats = booking.getSeats();
            for(Seat seat : seats){
                bookedSeats.add(seat.toCode());
            }
        }
        return bookedSeats;
    }
    private List<String> getAllSeats(String screeningId) {
        List<String> allSeat = new ArrayList<>();
        Screening screening = screeningRepository.findById(screeningId).orElseThrow(() -> new AppException(ErrorCode.SCREENING_NOT_FOUND));
        Theater theater = screening.getTheater();
        List<Seat> seats = theater.getSeats();
        for(Seat seat : seats){
            allSeat.add(seat.toCode());
        }
        return allSeat;
    }
    public BookedSeatResponse getSeatOfScreening(String screeningId){
        return BookedSeatResponse.builder()
                .allSeat(getAllSeats(screeningId))
                .bookedSeats(getAllBookedSeat(screeningId))
                .build();
    }
}
