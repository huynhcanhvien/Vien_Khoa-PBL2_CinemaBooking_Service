package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    String id;

    LocalDate bookingDate;
    LocalTime bookingTime;
    BigDecimal bookingPrice;

    @ManyToOne
    @JoinColumn(name = "user_id")
    User user;

    @ManyToOne
    @JoinColumn(name = "screening_id")
    Screening screening;

    @ManyToMany
    @JoinTable(
            name = "booking_seat",
            joinColumns = @JoinColumn(name = "booking_id"),
            inverseJoinColumns = @JoinColumn(name = "seat_id")

    )
    List<Seat> seats = new ArrayList<>();

    public List<String> getBookedSeatCodes() {
        List<String> seatCodes = new ArrayList<>();
        for (Seat seat : seats) {
            seatCodes.add(seat.toCode());
        }
        return seatCodes;
    }

    public void setUser(User user) {
        this.user = user;
        if(!user.getBookings().contains(this)) {
            user.addBooking(this);
        }
    }
    public void setScreening(Screening screening) {
        this.screening = screening;
        if(!screening.getBookings().contains(this)) {
            screening.addBooking(this);
        }
    }
    public void addSeat(Seat seat) {
        if (!seats.contains(seat)) {
            seats.add(seat);
            seat.addBooking(this);
        }
    }

    public void removeSeat(Seat seat) {
        if (seats.contains(seat)) {
            seats.remove(seat);
            seat.removeBooking(this);
        }
    }
}
