package com.example.cinemabooking_service.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScreeningOfMovieResponse {
    LinkedHashMap<LocalDate, List<ScreeningResponse>> screenings;

    public void addScreening(ScreeningResponse screening){
        if(screenings == null){
            screenings = new LinkedHashMap<>();
        }
        if(!screenings.containsKey(screening.getDateShow())){
            screenings.put(screening.getDateShow(), new ArrayList<>());
            screenings.get(screening.getDateShow()).add(screening);
        }
        else {
            screenings.get(screening.getDateShow()).add(screening);
        }
    }
    public void sort(){
        List<LocalDate> dateShows = new ArrayList<>();
        for (LocalDate date : screenings.keySet()){
            dateShows.add(date);
            dateShows.sort(LocalDate::compareTo);
        }
        LinkedHashMap<LocalDate, List<ScreeningResponse>> sortedScreenings = new LinkedHashMap<>();
        for (LocalDate date : dateShows){
            screenings.get(date).sort(Comparator.comparing(ScreeningResponse::getStartTime));
            sortedScreenings.put(date, screenings.get(date));
        }
        screenings = sortedScreenings;
    }
}
