package com.example.cinemabooking_service.repository;

import com.example.cinemabooking_service.entity.InvalidToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Date;

@Repository
public interface InvalidTokenRepository extends JpaRepository<InvalidToken, String> {
    void deleteByExpiredTimeBefore(Date expiredTime);
}
