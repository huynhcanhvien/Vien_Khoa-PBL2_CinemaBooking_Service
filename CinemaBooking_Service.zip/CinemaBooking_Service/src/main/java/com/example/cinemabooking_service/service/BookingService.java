package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.request.BookingRequest;
import com.example.cinemabooking_service.dto.response.BookingResponse;
import com.example.cinemabooking_service.dto.response.ScreeningResponse;
import com.example.cinemabooking_service.entity.*;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.repository.*;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class BookingService {
    BookingRepository bookingRepository;
    UserRepository userRepository;
    ScreeningRepository screeningRepository;

    public BookingResponse book(BookingRequest bookingRequest) {
        var contextHolder = SecurityContextHolder.getContext();
        String userName = contextHolder.getAuthentication().getName();

        User user = userRepository.findByUsername(userName)
                .orElseThrow(() -> new AppException(ErrorCode.USERNAME_NOT_FOUND));

        Screening screening = screeningRepository.findById(bookingRequest.getScreeningId())
                .orElseThrow(() -> new AppException(ErrorCode.SCREENING_NOT_FOUND));

        Theater theater = screening.getTheater();
        Movie movie = screening.getMovie();

        Booking booking = new Booking();


        for (String seatCode : bookingRequest.getSeatCodes()) {
            Seat seat = theater.getSeats().stream()
                    .filter(s -> s.toCode().equals(seatCode))
                    .findFirst()
                    .orElseThrow(() -> new AppException(ErrorCode.SEAT_NOT_FOUND));

            if (!seat.isBookedForScreening(screening)) {
                booking.addSeat(seat);
                log.info("Seat {} booked successfully.", seatCode);
            } else {
                log.warn("Seat {} is already booked.", seatCode);
                throw new AppException(ErrorCode.SEAT_IS_BOOKED);
            }
        }

        booking.setUser(user);
        booking.setScreening(screening);
        booking.setBookingDate(LocalDate.now());
        booking.setBookingTime(LocalTime.now());
        booking.setBookingPrice(calculateTotalPrice(movie, bookingRequest.getSeatCodes()));

        bookingRepository.save(booking);
        log.info("Booking saved successfully for user: {}", userName);

        ScreeningResponse screeningResponse = ScreeningResponse.builder()
                .theaterName(theater.getName())
                .movieName(screening.getMovie().getTitle())
                .startTime(screening.getStartTime())
                .endTime(screening.getEndTime())
                .dateShow(screening.getDateShow())
                .build();

        return BookingResponse.builder()
                .username(userName)
                .BookedDate(booking.getBookingDate())
                .BookedTime(booking.getBookingTime())
                .seatCodes(booking.getBookedSeatCodes())
                .screeningResponse(screeningResponse)
                .price(calculateTotalPrice(movie, bookingRequest.getSeatCodes()))
                .build();
    }
    public BigDecimal calculateTotalPrice(Movie movie, List<String> seatCodes) {
        BigDecimal moviePrice = movie.getPrice();
        BigDecimal numberOfSeats = new BigDecimal(seatCodes.size());

        return moviePrice.multiply(numberOfSeats);
    }
    public BigDecimal calculateRevenueByDate(LocalDate date) {
        BigDecimal revenue =  bookingRepository.calculateRevenueByDate(date);
        return revenue != null ? revenue : BigDecimal.ZERO;
    }
}
