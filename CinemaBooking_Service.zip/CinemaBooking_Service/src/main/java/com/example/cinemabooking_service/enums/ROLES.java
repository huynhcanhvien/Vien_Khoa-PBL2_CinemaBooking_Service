package com.example.cinemabooking_service.enums;

public enum ROLES {
    ADMIN,
    USER
}
