package com.example.cinemabooking_service.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import lombok.experimental.FieldDefaults;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MovieResponse {
    String id;
    String title;
    String posterURL;
    int duration; //in minutes
    String director_name;
    String genre;
    int for_age;
    BigDecimal price;
    LocalDate release_date;
    String description;
    String country;
    String language;
}
