package com.example.cinemabooking_service.controller;

import com.example.cinemabooking_service.dto.request.ScreeningRequest;
import com.example.cinemabooking_service.dto.response.ApiResponse;
import com.example.cinemabooking_service.dto.response.ScreeningResponse;
import com.example.cinemabooking_service.service.ScreeningService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/screening")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ScreeningController {

    ScreeningService screeningService;

    @PostMapping("/create")
    public ResponseEntity<ScreeningResponse> create(@RequestBody ScreeningRequest screeningRequest){
        return ResponseEntity.status(HttpStatus.CREATED).body(screeningService.createScreening(screeningRequest));
    }

    @PatchMapping("/update/{screeningId}")
    public ResponseEntity<ScreeningResponse> update(@PathVariable("screeningId") String screeningId,@RequestBody Map<String, Object> screeningRequest){
        return ResponseEntity.status(HttpStatus.OK).body(screeningService.updateScreening(screeningId, screeningRequest));
    }
    @GetMapping("/{screeningId}")
    public ResponseEntity<ScreeningResponse> get(@PathVariable("screeningId") String screeningId){
        return ResponseEntity.status(HttpStatus.OK).body(screeningService.getScreening(screeningId));
    }
    @DeleteMapping("/{screeningId}")
    public ApiResponse<Object> delete(@PathVariable("screeningId") String screeningId){
        boolean deleted = screeningService .deleteScreening(screeningId);
        return ApiResponse.builder()
                .message("Screening is deleted")
                .result(deleted)
                .build();
    }

    @GetMapping("/movie/{movieId}")
    public ApiResponse<Object> getAllScreeningOfMovie(@PathVariable("movieId") String movieId){
        return ApiResponse.builder()
                .result(screeningService.getAllScreenings(movieId))
                .build();
    }
    @GetMapping("/seats/{screeningId}")
    public ApiResponse<Object> getAllSeatsOfScreening(@PathVariable("screeningId") String screeningId){
        return ApiResponse.builder()
                .result(screeningService.getSeatOfScreening(screeningId)).build();
    }
}
