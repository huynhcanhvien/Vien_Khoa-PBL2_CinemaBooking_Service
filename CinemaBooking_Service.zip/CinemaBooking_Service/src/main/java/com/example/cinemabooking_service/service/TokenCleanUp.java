package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.repository.InvalidTokenRepository;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;


@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class TokenCleanUp {
    InvalidTokenRepository invalidTokenRepository;
    // xo'a sau cuoi ngay
    @Scheduled(cron = "0 0 0 * * ?")
    public void deleteExpiredTokens() {
        invalidTokenRepository.deleteByExpiredTimeBefore(Date.from(Instant.now().minus(3, ChronoUnit.DAYS)));
    }
}
