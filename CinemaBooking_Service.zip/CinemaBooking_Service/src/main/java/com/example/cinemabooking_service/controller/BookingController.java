package com.example.cinemabooking_service.controller;

import com.example.cinemabooking_service.dto.request.BookingRequest;
import com.example.cinemabooking_service.dto.response.ApiResponse;
import com.example.cinemabooking_service.dto.response.BookingResponse;
import com.example.cinemabooking_service.service.BookingService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@RestController
@RequestMapping("/booking")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class BookingController {
    BookingService bookingService;
    @PostMapping("/book")
    public ResponseEntity<BookingResponse> book(@RequestBody BookingRequest bookingRequest) {
        return ResponseEntity.status(HttpStatus.CREATED).body(bookingService.book(bookingRequest));
    }
    @GetMapping("/{date}")
    public ApiResponse<BigDecimal> calculateRevenueByDate(@PathVariable LocalDate date) {
        return ApiResponse.<BigDecimal>builder()
                .result(bookingService.calculateRevenueByDate(date))
                .message(date.toString())
                .build();
    }
}

