package com.example.cinemabooking_service.controller;

import com.example.cinemabooking_service.dto.request.TheaterRequest;
import com.example.cinemabooking_service.dto.response.ApiResponse;
import com.example.cinemabooking_service.dto.response.TheaterResponse;
import com.example.cinemabooking_service.service.TheaterService;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/theater")
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class TheaterController {
    TheaterService theaterService;
    // Post method
    @PostMapping("/add")
    public ResponseEntity<TheaterResponse> addTheater(@RequestBody TheaterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(theaterService.addTheater(request.getName(), request.getTotalSeat(), request.getSeatPerRow()));
    }
    // Update method
    @PatchMapping("/update/{theaterId}")
    public ResponseEntity<TheaterResponse> updateTheater(@PathVariable("theaterId") Long theaterId, @RequestParam("totalSeats") int totalSeats) {
        return ResponseEntity.ok(theaterService.update(theaterId, totalSeats));
    }
    // Get method:
    @GetMapping("/{theaterId}")
    public ResponseEntity<TheaterResponse> getTheater(@PathVariable("theaterId") Long theaterId) {
        return ResponseEntity.status(HttpStatus.FOUND).body(theaterService.findById(theaterId));
    }
    @GetMapping("/theaterName/{theaterName}")
    public ResponseEntity<TheaterResponse> getTheaterByName(@PathVariable("theaterName") String theaterName) {
        return ResponseEntity.status(HttpStatus.FOUND).body(theaterService.findByName(theaterName));
    }
    @GetMapping()
    public ApiResponse<Object> getTheaters() {
        return ApiResponse.builder().result(theaterService.getAllTheater()).build();
    }
    // Delete method
    @DeleteMapping("/{theaterId}")
    public ResponseEntity<Boolean> deleteTheater(@PathVariable("theaterId") Long theaterId) {
        return ResponseEntity.status(HttpStatus.OK).body(theaterService.delete(theaterId));
    }
}
