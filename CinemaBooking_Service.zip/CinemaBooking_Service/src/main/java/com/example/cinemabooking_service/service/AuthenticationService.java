package com.example.cinemabooking_service.service;

import com.example.cinemabooking_service.dto.request.AuthenticateRequest.AuthenticationRequest;
import com.example.cinemabooking_service.dto.request.AuthenticateRequest.IntrospectRequest;
import com.example.cinemabooking_service.dto.request.AuthenticateRequest.LogoutRequest;
import com.example.cinemabooking_service.dto.request.AuthenticateRequest.RefreshRequest;
import com.example.cinemabooking_service.dto.response.AuthenticationResponse;
import com.example.cinemabooking_service.dto.response.IntrospectResponse;
import com.example.cinemabooking_service.entity.InvalidToken;
import com.example.cinemabooking_service.entity.User;
import com.example.cinemabooking_service.exception.AppException;
import com.example.cinemabooking_service.exception.ErrorCode;
import com.example.cinemabooking_service.repository.InvalidTokenRepository;
import com.example.cinemabooking_service.repository.UserRepository;
import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.StringJoiner;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class AuthenticationService {
    UserRepository userRepository;
    InvalidTokenRepository invalidTokenRepository;


    @NonFinal
    @Value("${jwt.signerkey}")
    protected String SIGNED_KEY;

    @NonFinal
    @Value("${jwt.refreshable-duration}")
    private long REFRESHABLE_DURATION;

    @NonFinal
    @Value("${jwt.valid-duration}")
    private long VALIDATION_DURATION;

    public IntrospectResponse introspect(IntrospectRequest request) throws ParseException, JOSEException {
        var token = request.getToken();
        boolean isValid = true;
        try{
            verifyToken(token, false);
        }
        catch(AppException e){
            isValid = false;
        }

        return IntrospectResponse.builder()
                .valid(isValid)
                .build();
    }

    private SignedJWT verifyToken(String token, boolean isFresh) throws ParseException, JOSEException {
        log.info("Verifying token: {}", token);
        JWSVerifier verifier = new MACVerifier(SIGNED_KEY.getBytes());

        SignedJWT signedJWT = SignedJWT.parse(token);
        Date expirationDate = (isFresh) ? new Date(signedJWT.getJWTClaimsSet()
                .getIssueTime().toInstant().plus(REFRESHABLE_DURATION, ChronoUnit.SECONDS).toEpochMilli())
                : signedJWT.getJWTClaimsSet().getExpirationTime();
        boolean verified = signedJWT.verify(verifier);
        if (!(verified && expirationDate.after(new Date()))) {
            if (!verified) {
                log.error("JWT verification failed due to invalid signature.");
            } else if (!expirationDate.after(new Date())) {
                log.error("JWT verification failed due to expired token. Expiration: {}", expirationDate);
            }
            throw new AppException(ErrorCode.UNAUTHENTICATED);
        }

        if(invalidTokenRepository.existsById(signedJWT.getJWTClaimsSet().getJWTID()))
            throw new AppException(ErrorCode.UNAUTHENTICATED);

        log.info("Token verified successfully");
        return signedJWT;
    }

    private String buildscope(User user) {
        StringJoiner stringJoiner = new StringJoiner(" ");
        if (!CollectionUtils.isEmpty(user.getRoles())) {
            user.getRoles().forEach(stringJoiner::add);
        }
        return stringJoiner.toString();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest authenticationRequest) {
        var user = userRepository.findByUsername(authenticationRequest.getUsername()).
                orElseThrow(() -> new AppException(ErrorCode.USERNAME_NOT_FOUND));
        PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10);
        boolean authenticated = passwordEncoder.matches(authenticationRequest.getPassword(), user.getPassword());
        if (!authenticated) {
            throw new AppException(ErrorCode.UNAUTHENTICATED);
        }
        String token = generateToken(user);
        return AuthenticationResponse.builder()
                .token(token)
                .authenticated(true)
                .build();
    }

    public void logout(LogoutRequest request) throws ParseException, JOSEException {
        log.info("Logout are running");
        try{
            var signedToken = verifyToken(request.getToken(), true);
            String jid = signedToken.getJWTClaimsSet().getJWTID();
            log.info("JID: {}", jid);
            Date expirationDate = signedToken.getJWTClaimsSet().getExpirationTime();
            InvalidToken invalidToken = InvalidToken.builder()
                    .id(jid)
                    .expiredTime(expirationDate)
                    .build();
            invalidTokenRepository.save(invalidToken);
        }
        catch (AppException exception){
            throw new AppException(ErrorCode.TOKEN_EXPIRED);
        }
    }

    private String generateToken(User user) {
        JWSHeader header = new JWSHeader(JWSAlgorithm.HS512);

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
                .subject(user.getUsername())
                .issuer("huynhcanhvien")
                .issueTime(new Date())
                .expirationTime(new Date(Instant.now().plus(VALIDATION_DURATION, ChronoUnit.SECONDS).toEpochMilli()))
                .jwtID(UUID.randomUUID().toString())
                .claim("scope", buildscope(user))
                .build();
        Payload payload = new Payload(claimsSet.toJSONObject());

        JWSObject jwsObject = new JWSObject(header, payload);

        try {
            jwsObject.sign(new MACSigner(SIGNED_KEY));
            return jwsObject.serialize();
        } catch (JOSEException e) {
            throw new RuntimeException();
        }
    }


    public AuthenticationResponse refreshToken(RefreshRequest request) throws ParseException, JOSEException {
        SignedJWT verifier = verifyToken(request.getToken(), true);

        String jid = verifier.getJWTClaimsSet().getJWTID();
        Date expirationDate = verifier.getJWTClaimsSet().getExpirationTime();

        InvalidToken invalidToken = InvalidToken.builder()
                                                .id(jid)
                                                .expiredTime(expirationDate)
                                                .build();

        invalidTokenRepository.save(invalidToken);

        User user_refresh = userRepository.findByUsername(
                verifier
                .getJWTClaimsSet().getSubject())
                .orElseThrow(() -> new AppException(ErrorCode.USERNAME_INVALID)
                );

        String token = generateToken(user_refresh);

        return AuthenticationResponse.builder()
                .token(token)
                .authenticated(true)
                .build();

    }
}
