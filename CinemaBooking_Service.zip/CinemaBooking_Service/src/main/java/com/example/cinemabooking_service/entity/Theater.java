package com.example.cinemabooking_service.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@FieldDefaults(level = AccessLevel.PRIVATE)
@Slf4j
public class Theater {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    String name;
    int totalSeats;
    int seatsPerRow;
    int seatsAvailable;
    @OneToMany(mappedBy = "theater", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Screening> screenings = new ArrayList<>();

    @OneToMany(mappedBy = "theater", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Seat> seats = new ArrayList<>();

    @Transient
    Map<String, Seat> seatMap = new HashMap<>();

    public void generateSeats() {
        char rowLetter = 'A';
        int seatsPerRow = this.seatsPerRow;
        int totalSeats = this.totalSeats;

        for (int i = 0; i < totalSeats; i++) {
            int column = (i % seatsPerRow) + 1;
            if (column == 1 && i != 0) {
                rowLetter++;
            }
            Seat seat = new Seat(rowLetter, column, this);
            addSeat(seat);
        }
    }
    public void addSeat(Seat seat) {
        seats.add(seat);
        seat.setTheater(this);
        String keySeat = seat.toCode();
        seatMap.put(keySeat, seat);
    }
    public void removeSeat(Seat seat) {
        if (seat != null && seats.contains(seat)) {
            seats.remove(seat);
            seatMap.remove(seat.toCode());
            seat.setTheater(null);
        }
    }

    public void addScreening(Screening screening) {
        screenings.add(screening);
        if(!screening.getTheater().equals(this)) {
            screening.setTheater(this);
        }
    }
    public void removeScreening(Screening screening) {
        if (screening != null && screenings.contains(screening)) {
            screenings.remove(screening);
            screening.setTheater(null);

        }
    }
    public void printSeatMap() {
        if (seatMap.isEmpty()) {
            log.info("Seat map is empty!");
        } else {
            log.info("Seat map contains the following seats:");
            seatMap.keySet().forEach(log::info);
        }
    }
}
